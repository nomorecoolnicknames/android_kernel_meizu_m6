crosFpsCounter = function() {
  this.totalElapsedTime = 0.0;
  this.totalRenderTime = 0.0;
  this.totalFrames = 0;
}

crosFpsCounter.prototype.update = function(elapsedTime, renderTime) {
  this.totalElapsedTime += elapsedTime;
  this.totalRenderTime += renderTime;
  this.totalFrames += 1;
}

crosFpsCounter.prototype.reset = function() {
  this.totalElapsedTime = 0.0;
  this.totalRenderTime = 0.0;
  this.totalFrames = 0;
}

crosFpsCounter.prototype.getAvgFps = function() {
  return this.totalFrames / this.totalElapsedTime;
}

crosFpsCounter.prototype.getAvgRenderTime = function() {
  return this.totalRenderTime / this.totalFrames;
}
